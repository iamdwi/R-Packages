.First.lib =
 function(libname, pkgname, where)
{
  library.dynam(pkgname, pkgname)
}

